#include <iostream>
#include <cstdlib>
#include <ctime>

#include "MaxHeap.h"
#include "SortAlgorithms.h"

   using namespace std;



int main () {

	// write code here to perform experiments with the sort algorithms
	
	return 0;
}
